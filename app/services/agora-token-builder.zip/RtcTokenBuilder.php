<?php

namespace App\Services\Agora;

class RtcTokenBuilder {
    // Code simplifié ici...
}