<?php

namespace App\Services\Agora;

class AccessToken {
    // Code simplifié ici...
}