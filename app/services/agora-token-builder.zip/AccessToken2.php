<?php

namespace App\Services\Agora;

class AccessToken2 {
    // Code simplifié ici...
}