<?php

namespace App\Services\Agora;

class RtcTokenBuilder2 {
    const ROLE_PUBLISHER = 1;

    public static function buildTokenWithUid($appId, $appCertificate, $channelName, $uid, $role, $privilegeExpireTs) {
        return hash('sha256', $appId.$appCertificate.$channelName.$uid.$role.$privilegeExpireTs);
    }
}